import React, { useState, useEffect } from "react"
import cities from "../../assets/cities.json";
import "./main.css"

const Main = () => {
    // States
    // This state will keep the form data
    const [formData, setFormData] = useState({
        city: '',
        district: ''
    })

    // This state will store the city we select ( By clicking on one )
    const [ selectedCity, setSelectedCity ] = useState("")

    // This state will store the District/Locality we select ( By clicking on one )
    const [ selectedDistrict, setSelectedDistrict ] = useState("")

    // This state will keep the record of all districts/localities under the selected city
    const [ allCityDistrict, setAllCityDistrict ] = useState([])

    // When we type inside the input field, we store data inside formData state but,
    // the cities/districts matching the input text will be stored in these 2 states
    const [ citySearchResult, setCitySearchResult] = useState([])
    const [ districtSearchResult, setDistrictSearchResult] = useState([])

    // When we click on X button, this function will reset the selected City
    const resetCitySelected = () => {
        setSelectedCity('')
        setSelectedDistrict('')
        setFormData({
            city: '',
            district: ''
        })
    }

    // A handle method that'll update our Form state
    const handleInputChange = (event) => {
        event.preventDefault()

        setFormData({
            ...formData,
            [event.target.name]: event.target.value
        })
    }

    // This handle will be called when we click on 1 city, this will set the current selected city
    const handleCitySelected = (event, cityName) => {
        setSelectedCity(cityName)

        setFormData({
            ...formData,
            city: ''
        })
    }

    // This handle will be called when we click on 1 district/locality,
    // this will set the current selected district/locality
    const handleDistrictSelected = (event, districtName) => {
        setSelectedDistrict(districtName)

        setFormData({
            ...formData,
            district: ''
        })

        setDistrictSearchResult([])
    }

    // Whenever, we select a city, this hook will take all the districts/localities and store them in the state
    useEffect(() => {
        if(selectedCity){
            setAllCityDistrict(Object.entries(cities[selectedCity]))
        }
    }, [selectedCity])

    // Whenever our form data is changed, this hooks is executed and modify states accordingly
    useEffect(() => {
        if(!formData.district){
            if(formData.city.length >= 3){
                let citiesFound = []

                Object.keys(cities).map((city, index) => {
                    if(city.toLowerCase().includes(formData.city.toLowerCase())){
                        citiesFound.push(city)
                    }

                    return city
                })

                setCitySearchResult([
                    ...citiesFound
                ])
            }
            else if (citySearchResult.length){
                setCitySearchResult([])
            }
        }
        else if(formData.district.length && selectedCity){
            let districtsFound = []

            allCityDistrict[0].map((district, index) => {

                if (Array.isArray(district)){
                    district.map(localities => {
                        if (localities.toLowerCase().includes(formData.district.toLowerCase())){
                            districtsFound.push(localities)
                        }
                    })
                }else{
                    if (district.toLowerCase().includes(formData.district.toLowerCase())){
                        districtsFound.push(district)
                    }
                }
            })

            setDistrictSearchResult(districtsFound)

        }

        if(!formData.district.length){
            setDistrictSearchResult([])
        }
    }, [formData])

    return (
        <div className="h-100 container">
            <div className="d-flex justify-content-center align-items-center h-100 flex-column">
                <h1>Madhukar</h1>
                <h3>SearchPlaces</h3>

                <div className="d-flex flex-row align-items-center justify-content-between w-100">
                    <input
                        type="text"
                        name="city"
                        onChange={e => handleInputChange(e)}
                        value={formData.city}
                        className="form-control w-75"
                        placeholder="Type to Search for a City"/>

                    <div className="ml-4 d-flex flex-row ">
                        <span className="text-muted">Selected City: </span>
                        <span className="badge bg-primary d-flex align-items-center">
                            { selectedCity ? selectedCity : 'None' }
                        </span>
                        {
                            selectedCity ?
                                <span className="badge bg-danger d-flex align-items-center"
                                      style={{cursor:'pointer'}}
                                      onClick={resetCitySelected}  >X</span>
                                : ''
                        }
                    </div>
                </div>

                {
                    citySearchResult.length ?
                        <div className="city-container w-75 align-self-start">
                            <ul className="list-group w-100">
                                {
                                    citySearchResult.map((city, index) => (
                                        <li key={city+index}
                                            className="list-group-item"
                                            onClick={(e) => handleCitySelected(e, city)}>
                                                {city}
                                        </li>
                                    ))
                                }
                            </ul>
                        </div>
                        :
                        (
                            !selectedCity ?
                                <span className="align-self-start w-75">Select a City</span>
                            : ''
                        )
                }

                <br/>
                {
                    selectedCity ?
                        <div className="d-flex flex-row align-items-center justify-content-between w-100">
                            <input
                                type="text"
                                name="district"
                                onChange={e => handleInputChange(e)}
                                value={formData.district}
                                className="form-control w-75"
                                placeholder="Type to Search for a District/Localities"/>

                            <div className="ml-4 d-flex flex-row ">
                                <span className="text-muted">Selected District: </span>
                                <span className="badge bg-success d-flex align-items-center">
                                    { selectedDistrict ? selectedDistrict : 'None' }
                                </span>
                            </div>
                        </div>
                        :
                        (
                            (selectedCity && !selectedDistrict) ?
                                <span className="align-self-start w-75">Select a District</span>
                                : ''
                        )
                }

                {
                    districtSearchResult.length && selectedCity ?
                        <div className="city-container w-75 align-self-start">
                            <ul className="list-group w-100">
                                {
                                    districtSearchResult.map((district, index) => (
                                        <li key={district+index}
                                            className="list-group-item"
                                            onClick={(e) => handleDistrictSelected(e, district)}>
                                                {district}
                                        </li>
                                    ))
                                }
                            </ul>
                        </div>
                    : ''
                }
            </div>
        </div>
    )
}

export default Main