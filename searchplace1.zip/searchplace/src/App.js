import './App.css';
import Main from './components/main/main';

function App() {
  return (
    <div className="App h-100">
      <Main />
    </div>
  );
}

export default App;
